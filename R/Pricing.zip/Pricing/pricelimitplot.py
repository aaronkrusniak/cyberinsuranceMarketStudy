#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Sep 18 09:04:06 2018

@author: daniel
"""

from scipy.stats import norm
import numpy as np
import random
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from multiprocessing import Pool
import seaborn as sns
import pandas as pd
import csv

def nonfindeductible_asset(revenue):
    if revenue < 25000000:
        return 0
    elif revenue < 100000000:
        return 1
    elif revenue < 300000000:
        return 2
    elif revenue < 500000000:
        return 3
    elif revenue < 1000000000:
        return 4
    else:
        return 'Not sure if beyond this is possible'

def nonfinbaserate_asset(revenue):
    if revenue < 5000000:
        return 0
    elif revenue < 10000000:
        return 1
    elif revenue < 25000000:
        return 2
    elif revenue < 50000000:
        return 3
    elif revenue < 75000000:
        return 4
    elif revenue < 100000000:
        return 5
    elif revenue < 150000000:
        return 6
    elif revenue < 200000000:
        return 7
    elif revenue < 300000000:
        return 8
    elif revenue < 400000000:
        return 9
    elif revenue < 500000000:
        return 10
    elif revenue < 750000000:
        return 11
    elif revenue < 1000000000:
        return 12
    else:
        return 'Not sure coverage is offered beyond this point'



def ale_ins(cost, limit, deductible):
    return min(cost, deductible) + max(0, cost - limit)

def benefits_of_insurance(cost, limit, deductible, premium, frequency=1):
    return ((cost - ale_ins(cost, limit, deductible))*frequency - premium)*(100/premium)

def revenueadj_maker(string):
    func = ""
    ifclause = 'elif revenue < '
    action = ':' +'\n' + '    return '
    for drop in range(len(string)):
        func += ifclause + str(string[drop]) + action + str(drop) + '\n'
    return func

finindustries = pd.read_csv("finindustries.csv")
nonfinindustries = pd.read_csv("nonfinindustries.csv")


finbaserates = pd.read_csv("finbaserates.csv")
nonfinbaserates = pd.read_csv("nonfinbaserates.csv")
limits = pd.read_csv("limits.csv")
nonfindeductibles = pd.read_csv("nonfindeductibles.csv")
coverage = pd.read_csv("coverage.csv")
#NOTE: Coverage is highly subjective, based on the perceived rate of a given endorsement.
coverage = coverage.set_index('Coverage')
nonfinbaserates = nonfinbaserates.set_index('Revenue')
finbaserates = finbaserates.set_index('Asset Size')
nonfindeductibles = nonfindeductibles.set_index('Retention')
limits = limits.set_index('Limit')

ins_asset = 500000000

def worstcaselinear(p,l,d):
    return (0.5*(l*l) + l*d)/(l-p)

'''
for limit in range(len(limits)):
    #for deductible in range(len(nonfindeductibles)):
    deductible =  3
    baserate = nonfinbaserates.iloc[nonfinbaserate_asset(ins_asset)][0]*limits.iloc[limit]*nonfindeductibles.iloc[deductible][nonfindeductible_asset(ins_asset)]
    print(worstcaselinear(float(baserate), limits.index[limit], nonfindeductibles.index[deductible]), limits.index[limit])
    #print(float(baserate), limits.index[limit], nonfindeductibles.index[deductible])
'''

def priceperlimit(limitz, p):
    limits = [0, limitz.index[0]]
    average = [float((p*limitz.iloc[0]))/limits[1], float((p*limitz.iloc[0]))/limits[1]]
    for x in range(1, len(limitz)):
        limits.append(limitz.index[x])
        average.append((p*float(limitz.iloc[x])-average[x-1])/(limitz.index[x]-limits[x-1]))
        #average.append((p*limitz.iloc[x]-average[x])/(limitz.index[x]-limits[x]))
    return((limits, average))

holder = priceperlimit(limits, 100000)



plt.plot(holder[0],holder[1])
plt.set_xlabel('Limit')
plt.set_ylabel('Price per $ of Coverage')


'''
B = [ [1,n] for n in range(1,50) ]

N = 1000
y = np.zeros(N)
count = 1
for b in B:
    x = np.zeros(N)
    x[ np.arange(b[0]*1.0*N/b[1], N).astype(int)]=count**-2
    y += x
    count += 1

'''